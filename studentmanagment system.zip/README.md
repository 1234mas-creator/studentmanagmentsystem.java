# Student Management System

A simple Java console application for managing student records.

## Features
- Add Student
- View Students
- Search Student
- Delete Student

## Language
- Java

## Author
Mastewal Mihret